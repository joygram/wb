<?php
eval("dooutput(\"".gettemplate("database_delete_confirm")."\");");
?>