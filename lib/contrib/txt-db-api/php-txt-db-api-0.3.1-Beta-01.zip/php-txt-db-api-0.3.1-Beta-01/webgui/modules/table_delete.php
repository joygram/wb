<?php
eval("dooutput(\"".gettemplate("table_delete_confirm")."\");");
?>