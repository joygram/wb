<?php
eval("dooutput(\"".gettemplate("table_empty_confirm")."\");");
?>