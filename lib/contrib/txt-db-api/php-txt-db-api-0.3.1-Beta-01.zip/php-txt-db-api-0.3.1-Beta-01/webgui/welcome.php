<?php
$api_vers = txtdbapi_version();
eval("dooutput(\"".gettemplate("welcome")."\");");
?>